"""Phase XI AADS utilities."""
